1. Run from the getgo.
2. Ensure you have the proper images.
3. If not, change the input parameter that is being read in to an appropriate image.
4. Have fun!
5. Give me 100% :)